<img src="static/img/quizim_icon_col.svg" width=70 align=right>

# Quizim: Quizlet Improved

Quizim is an open-source web application to import and learn sets of flashcards from Quizlet.


## Project development

Contributions are welcome. :>

Please see [the Trello board](https://trello.com/b/sNl8QqnB/quizim-todo) for a TO-DO list.
